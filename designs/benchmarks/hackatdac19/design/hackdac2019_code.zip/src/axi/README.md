# AXI

This is the implementation of the AMBA AXI protocol developed as part of the PULP platform as ETH Zurich. This repository will eventually contain interface definitions, crossbars, data width converters, traffic generators, and testbench utilities.

We implement AXI4 and AXI4-Lite.
